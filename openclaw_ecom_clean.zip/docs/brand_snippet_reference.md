# E 系列技能標準品牌讀取 Snippet
# 每個 E01–E88 技能的 Python 執行區塊最開頭，貼上這段

---

## 完整 Snippet（貼到每個技能的 Python 區塊最前面）

```python
import json, os

# ╔══════════════════════════════════════════════╗
# ║        D02 多品牌讀取 — 每個E技能必備        ║
# ╚══════════════════════════════════════════════╝

PROFILE_DIR = "profiles"

def get_active_brand() -> dict:
    active_path = os.path.join(PROFILE_DIR, "active_brand.json")
    
    # 尚未建立任何品牌時的防呆
    if not os.path.exists(active_path):
        raise SystemExit(
            "⚠️ 尚未設定任何品牌！\n"
            "請先輸入 /brand new 建立你的第一個品牌，再使用此技能。"
        )
    
    with open(active_path, encoding="utf-8") as f:
        active = json.load(f)
    
    brand_path = os.path.join(PROFILE_DIR, f"{active['current_brand_id']}.json")
    
    if not os.path.exists(brand_path):
        raise SystemExit(
            "⚠️ 品牌檔案遺失！\n"
            "請輸入 /brand list 確認品牌狀態，或重新建立品牌。"
        )
    
    with open(brand_path, encoding="utf-8") as f:
        return json.load(f)

# 讀取品牌
brand = get_active_brand()

# 常用變數（直接解包，後面直接用）
BRAND_NAME     = brand["brand_name"]
BRAND_ALIAS    = brand["identity"]["brand_alias"]
INDUSTRY       = brand["identity"]["industry"]
MAIN_CATS      = brand["identity"]["main_categories"]      # list
PRICE_TIER     = brand["identity"]["price_tier"]
TARGET_AUD     = brand["identity"]["target_audience"]
BRAND_TONE     = brand["identity"]["brand_tone"]
USP            = brand["identity"]["usp"]
TABOO_WORDS    = brand["identity"]["taboo_words"]          # list

PLATFORMS      = brand["platforms"]                        # 各平台 dict
SOCIAL         = brand["social"]                           # 社群帳號 dict
OPS            = brand["operations"]                       # 營運設定 dict

# ══════════════════════════════════════════════
# 以下才是 [技能自己的邏輯]
# ══════════════════════════════════════════════
```

---

## 各平台 API 取用範例

```python
# 蝦皮
if PLATFORMS["shopee"]["enabled"]:
    shopee_api_key    = PLATFORMS["shopee"]["api_key"]
    shopee_api_secret = PLATFORMS["shopee"]["api_secret"]
    shopee_shop_id    = PLATFORMS["shopee"]["shop_id"]

# Momo
if PLATFORMS["momo"]["enabled"]:
    momo_seller_id = PLATFORMS["momo"]["seller_id"]
    momo_api_key   = PLATFORMS["momo"]["api_key"]

# 91APP
if PLATFORMS["app_91"]["enabled"]:
    app91_store_id  = PLATFORMS["app_91"]["store_id"]
    app91_api_token = PLATFORMS["app_91"]["api_token"]
```

---

## 技能開頭的品牌確認提示（多品牌時防呆）

在 Python 執行完讀取後，LLM 回應的第一行加上這個：

```
🏷️ 當前品牌：{BRAND_NAME}（{list(啟用平台)}）
   若要切換品牌，請先輸入 /brand use [品牌名稱]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

只有學員有 **2 個以上品牌** 時才顯示這段（避免單品牌學員每次都看到干擾訊息）：

```python
# 判斷是否需要顯示品牌確認提示
import glob
brand_count = len(glob.glob(os.path.join(PROFILE_DIR, "brand_*.json")))
SHOW_BRAND_REMINDER = brand_count > 1
```

---

## SKILL.md 裡的寫法（放在技能的「執行流程」最上方）

```yaml
execution:
  pre_check:
    - action: python
      script: E_brand_snippet  # 每個技能統一引用這段
      on_error: abort_with_message  # 失敗就中止並回報錯誤

  main:
    # ... 技能自己的邏輯從這裡開始 ...
```

---

## 快速對照表：舊寫法 vs 新寫法

| 舊寫法（硬寫佔位符）| 新寫法（從 Profile 讀取）|
|---|---|
| `brand = "[你的品牌]"` | `brand = BRAND_NAME` |
| `tone = "[品牌語氣]"` | `tone = BRAND_TONE` |
| `api_key = "[蝦皮API]"` | `api_key = PLATFORMS["shopee"]["api_key"]` |
| `taboo = []` | `taboo = TABOO_WORDS` |
| `audience = "[目標客群]"` | `audience = TARGET_AUD` |

---

## 注意事項

- **API Key 等敏感資訊只在 Python 執行層使用**，絕對不能出現在 LLM 回應的文字中
- `TABOO_WORDS` 要傳給所有會生成文案的技能（E22、E31、E45 等），讓 LLM 自動迴避
- 如果某技能只需要 `BRAND_NAME` 和 `BRAND_TONE`，其他變數不用解包也沒關係，不影響執行
