---
name: c05-sandbox-browser
description: 讓龍蝦用專屬瀏覽器瀏覽網頁、擷取截圖、抓取網頁內容、分析競品頁面，以及填寫表單等自動化操作
user-invocable: true
metadata: {"openclaw":{"emoji":"🌐","requires":{"config":["browser.enabled"]}}}
---

# 沙盒瀏覽器

龍蝦有一個自己專屬的 Chromium 瀏覽器，可以幫你瀏覽網站、截圖、抓資料。這跟 C06 爬蟲的差別是：瀏覽器能處理 JavaScript 渲染的頁面（蝦皮、Momo、FB 廣告後台這類動態網站都可以）。

## 啟用瀏覽器（首次設定）

瀏覽器功能需要在 Oracle VM 上安裝 Chromium。告訴用戶執行：

```bash
# 安裝 Chromium（ARM 版）
sudo apt-get install -y chromium-browser

# 確認安裝成功
chromium-browser --version
```

然後在 `~/.openclaw/openclaw.json` 加入：
```json
{
  "browser": {
    "enabled": true,
    "headless": true
  }
}
```

重啟服務：`sudo systemctl restart openclaw`

## 你能做的事

### 瀏覽網頁 + 截圖
當用戶說「去看這個網頁」「截圖這個網址」時：
- 用瀏覽器開啟指定 URL
- 截取完整頁面截圖
- 回傳截圖給用戶，並附上頁面標題和摘要
- 範例：「/c05 截圖 https://shopee.tw/某個商品」

### 擷取頁面內容
當用戶說「抓這個頁面的內容」「這個網頁說什麼」時：
- 開啟頁面等待 JavaScript 渲染完成
- 擷取主要文字內容
- 用中文摘要給用戶

### 競品頁面分析
當用戶說「分析這個競品頁面」時：
- 開啟競品商品頁
- 擷取：標題、價格、評分、描述、規格、圖片數量
- 整理成結構化摘要回傳

### 自動填寫表單（進階）
當用戶需要重複填寫固定格式的表單時，可以自動化操作。請先確認用戶了解這是對目標網站的自動化操作，確保符合網站使用條款。

## 與其他 skill 的搭配

- **E01 競品價格監控**：瀏覽器抓動態頁面的即時價格
- **E09 暢銷榜追蹤**：開啟排行榜頁面擷取排名資料
- **E29 SERP 分析**：開啟 Google 搜尋結果頁面截圖分析
- **E52 競品廣告監控**：開啟 Facebook Ad Library 截圖

## 注意事項

- 每次瀏覽器操作需要數秒，比純 API 爬蟲慢，但能處理動態網站
- 瀏覽器跑在 Oracle VM 上（headless 模式，沒有視覺介面）
- 截圖會自動壓縮後傳給用戶，蝦皮等複雜頁面可能需要等 5-10 秒
- 不要用於需要登入的頁面（會話管理複雜，超出此 skill 範圍）

## 常見問題排除

**「瀏覽器無法啟動」**
```bash
# 確認 Chromium 已安裝
which chromium-browser

# 確認 browser.enabled 在設定裡
cat ~/.openclaw/openclaw.json | grep browser
```

**「截圖是空白的」**
- 頁面可能載入太慢，告訴龍蝦「等頁面完全載入再截圖」
- 有些網站有 bot 偵測，可能需要等待或換時間重試

**「ARM 版 Chromium 有問題」**
Oracle ARM VM 上的 Chromium 偶爾有相容性問題，備用方案：
```bash
# 改用 Playwright 版 Chromium
npx playwright install chromium
```

## 語氣要求
- 繁體中文
- 瀏覽器操作需要時間，先告訴用戶「正在開啟頁面...」再執行
- 截圖完成後簡短說明看到了什麼，不要只傳圖不說話

---

## Subagent 調教

**派遣類型**：sa03-crawler（爬蟲龍蝦）
**角色人格**：敏銳的網頁探索員，擅長從動態頁面找出最重要的資訊，過濾廣告和雜訊

**派遣時機**：瀏覽完頁面後，將原始擷取資料交給爬蟲龍蝦整理過濾，再回傳結構化結果給用戶。單純截圖或開啟頁面操作不需派遣。

執行本 Skill 需要派遣 subagent 時，使用以下格式：

```
[PERSONA] 你是一位敏銳的網頁探索員。優先擷取標題、價格、日期、評分等結構化資訊。廣告欄位、導覽選單、無關區塊一律不回傳。截圖完成後用一句話說明看到了什麼。
[TASK] {從用戶輸入萃取的具體任務}
[CONSTRAINTS] {根據用戶情境填入限制條件，例如字數、時間範圍、目標平台}
```

Subagent 完成任務後，主龍蝦整合結果並以本 Skill 定義的格式回覆用戶。
