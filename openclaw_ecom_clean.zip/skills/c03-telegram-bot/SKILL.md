---
name: c03-telegram-bot
description: 設定 Telegram Bot、管理配對、傳送訊息、處理圖片截圖分析，以及排除 Telegram 連線問題。LINE 為主要推薦頻道（見 C04），Telegram 為可選替代頻道。
user-invocable: true
metadata: {"openclaw":{"emoji":"✈️","requires":{"env":["TELEGRAM_BOT_TOKEN"]}}}
---

# Telegram Bot 設定與管理

龍蝦支援 LINE（主要推薦）和 Telegram（可選）兩個頻道。台灣用戶建議優先使用 C04 LINE Bot，因為員工和客戶大多使用 LINE。如果學員偏好使用 Telegram，引導完成以下設定。

## 初次設定流程

當用戶說「我要設定 Telegram」「Telegram 怎麼設定」時，引導他們完成以下步驟：

**步驟一：建立 Bot**
1. 打開 Telegram，搜尋 `@BotFather`（藍色勾勾的官方帳號）
2. 發送 `/newbot`
3. 輸入 Bot 顯示名稱（例如：我的龍蝦助理）
4. 輸入 Bot 用戶名（必須以 `bot` 結尾，例如：mylobster_bot）
5. BotFather 會給你一個 Token，格式像：`123456789:ABCdefGHIjklmno`
6. 複製這個 Token

**步驟二：取消 Privacy Mode（群組用必做）**
1. 在 BotFather 發送 `/mybots`
2. 選擇你的 Bot
3. 點選 Bot Settings → Group Privacy → Turn Off
4. 這讓 Bot 在群組裡能讀到所有訊息，不只是 `/指令`

**步驟三：填入設定**
告訴用戶把 Token 填入 `~/.openclaw/openclaw.json` 的 `channels.telegram.botToken` 欄位，然後重啟服務：
```
sudo systemctl restart openclaw
```

**步驟四：配對**
1. 在 Telegram 找到自己的 Bot，發送任意訊息
2. Bot 會回傳一個配對碼（6位數字）
3. 在 Oracle VM 上執行：`openclaw pairing approve telegram <配對碼>`
4. 配對成功，龍蝦上線

## 傳送圖片與截圖分析

當用戶問「可以傳截圖嗎」「圖片怎麼分析」時：

直接說：**可以，直接傳圖片進來就好，不需要任何額外設定。**

使用方式：
- 傳截圖 + 說明文字：「/e40 這是我的 GA 數據，幫我分析」
- 傳競品頁面截圖：「/e01 這是蝦皮競品，幫我看一下定價策略」
- 傳廣告截圖：「/e52 這是對手 FB 廣告，幫我分析」

注意事項：
- 圖片大小上限 5MB
- 支援 JPG、PNG、WebP
- 如果截圖太模糊，AI 分析品質會下降，提醒用戶截清楚一點

## 常見問題排除

**Bot 沒有回應**
1. 確認服務有在跑：`sudo systemctl status openclaw`
2. 確認 Token 填對了：格式是 `數字:英數字母混合`
3. 查看日誌：`journalctl -u openclaw -n 30 --no-pager`
4. 常見錯誤：`401 Unauthorized` = Token 錯了；`409 Conflict` = 多個地方在跑同一個 Bot

**群組裡 Bot 不回應**
1. 確認已關閉 Privacy Mode（步驟二）
2. 把 Bot 踢出群組再重新加入（設定改變不會套用到舊有群組）
3. 在群組裡 @mention Bot 名稱後再輸入指令

**配對碼過期**
配對碼有效期 1 小時，過期就重新發訊息給 Bot 取得新碼

**只想讓自己用，不想開放給別人**
在設定裡改成 allowlist 模式：
```json
"dmPolicy": "allowlist",
"allowFrom": ["tg:你的用戶ID"]
```
用 @userinfobot 可以查到自己的 Telegram 數字 ID

## 語氣要求
- 繁體中文
- 步驟要清楚，每個步驟一個動作
- 遇到錯誤先問用戶看到的錯誤訊息，再給解法

---

## Subagent 調教

**派遣類型**：sa01-copywriter（文案龍蝦）
**角色人格**：親切的推播文案師，LINE 為主要頻道，Telegram 為可選替代，依用戶選擇調整語氣

**派遣時機**：當需要產生推播通知文字、歡迎訊息、Bot 回覆範本時派遣。設定、配對、排除故障等技術操作由主 Skill 直接執行，不需派遣。

執行本 Skill 需要派遣 subagent 時，使用以下格式：

```
[PERSONA] 你是一位親切的推播文案師。LINE 訊息：不超過 80 字，第一句抓住注意力，結尾加清楚的行動呼籲，善用 emoji 但不泛濫。若目標是 Telegram：語氣可以更簡短技術性，條列式呈現，重點資訊不超過 3 條。
[TASK] {從用戶輸入萃取的具體任務}
[CONSTRAINTS] {根據用戶情境填入限制條件，例如字數、時間範圍、目標平台}
```

Subagent 完成任務後，主龍蝦整合結果並以本 Skill 定義的格式回覆用戶。
