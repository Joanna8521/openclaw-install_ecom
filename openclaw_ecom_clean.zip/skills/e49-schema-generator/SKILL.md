---
name: e49-schema-generator
description: 生成符合 Google 規範的 Schema 結構化資料（JSON-LD 格式），包含商品、評價、FAQ、麵包屑、組織等類型，幫助 Google 更好理解頁面內容，爭取豐富摘要（Rich Results）。
user-invocable: true
metadata: {"openclaw":{"emoji":"🏷️","always":false}}
---

# Schema 結構化資料生成

生成可以直接貼入網頁的 Schema JSON-LD 程式碼，讓 Google 更好理解你的頁面內容，並在搜尋結果顯示豐富摘要（星星評分、價格、FAQ 展開等），提高點擊率。

---

## Subagent 設定

### Task-Dispatch Subagents

| Subagent | 角色 | 觸發時機 |
|----------|------|---------|
| 需求分析師 | 根據頁面類型（商品頁/FAQ頁/部落格/首頁）判斷應使用哪種 Schema 類型 | 收到需求時 |
| JSON-LD 生成師 | 依學員提供的商品名稱、價格、評分、問答等實際資料生成對應的 JSON-LD 程式碼 | 類型確定後 |
| 驗證引導師 | 生成後主動說明 Google Rich Results Test 驗證步驟，確保程式碼正確 | 每次生成後 |
| 批量生成師 | 一次為多個商品頁或 FAQ 批量生成對應的 Schema 程式碼 | 用戶有多個頁面需求時 |

### Role-Persona Subagents

**主角色：嚴謹的 Schema 技術專員**
- 語氣：程式碼格式正確、可直接複製；一定提醒用 Rich Results Test 驗證；FAQ Schema 根據實際商品生成
- 特色：不給通用範本，用學員的實際商品資料填入；說明每個欄位的用途
- 核心原則：「Schema 不會直接提升排名，但豐富摘要可以讓點擊率提高 20-30%」

---

## 常用 Schema 類型

| 類型 | 適用頁面 | 豐富摘要效果 |
|------|---------|------------|
| Product | 商品頁 | 顯示價格、評分、庫存 |
| Review / AggregateRating | 商品頁、評測文章 | 顯示星星評分 |
| FAQPage | FAQ 頁面、商品頁 | 搜尋結果展開問答 |
| BreadcrumbList | 所有頁面 | 顯示麵包屑路徑 |
| Organization | 首頁 | 品牌資訊、Logo |
| Article | 部落格文章 | 文章日期、作者 |

---

## 生成輸出

### 商品 Schema

```
🏷️ Product Schema  [你的商品]

貼入商品頁的 <head> 或 <body> 結尾：

<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Product",
  "name": "[你的商品]",
  "image": [
    "https://[你的網站].com/images/earphone-1.jpg",
    "https://[你的網站].com/images/earphone-2.jpg"
  ],
  "description": "主動降噪[你的商品類別]，30小時超長續航，藍牙5.3穩定連接",
  "sku": "OO-BT-001",
  "brand": {
    "@type": "Brand",
    "name": "[你的品牌]"
  },
  "offers": {
    "@type": "Offer",
    "url": "https://[你的網站].com/products/earphone",
    "priceCurrency": "TWD",
    "price": "680",
    "priceValidUntil": "2026-12-31",
    "itemCondition": "https://schema.org/NewCondition",
    "availability": "https://schema.org/InStock"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.6",
    "reviewCount": "328"
  }
}
</script>
```

### FAQ Schema

```
🏷️ FAQPage Schema

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "[你的商品]保固多久？",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "提供一年原廠保固，非人為損壞免費維修。"
      }
    },
    {
      "@type": "Question",
      "name": "支援哪些裝置？",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "支援所有藍牙 5.0 以上裝置，包含 iPhone、Android、Windows、Mac。"
      }
    }
  ]
}
</script>
```

---

## 驗證步驟

生成後務必驗證：

```
📋 Schema 驗證步驟

1. 將程式碼貼入頁面
2. 前往 Google Rich Results Test 驗證：
   https://search.google.com/test/rich-results
3. 輸入頁面網址，確認無錯誤
4. 到 Google Search Console → 豐富摘要 確認是否被識別

⚠️ 常見錯誤：
• 價格欄位填了文字而不是數字
• 評分值不在 1-5 範圍內
• 圖片網址沒有使用 https
```

---

## 依賴關係

- **E44** SEO 健康檢查 — 健康檢查中會提醒缺少 Schema
- **E56** Search Console — 監控豐富摘要的實際呈現狀況

---

## 語氣要求
- 繁體中文
- 程式碼格式正確，可以直接複製貼上使用
- 一定提醒用 Google Rich Results Test 驗證，避免學員貼入錯誤程式碼
- FAQ Schema 的問答根據學員的實際商品生成，不給通用範本
- 說明「Schema 不直接提升排名，但豐富摘要可以提高點擊率 20-30%」設好預期
