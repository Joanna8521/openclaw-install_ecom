---
name: c04-line-bot
description: 設定 LINE Messaging API Bot（主要推薦頻道）、處理 webhook 設定、完成配對、傳送訊息、截圖分析，以及排除 LINE 連線問題。
user-invocable: true
metadata: {"openclaw":{"emoji":"💚","always":false}}
---

# LINE Bot 設定

LINE 是 AICLAW 課程的主要推薦頻道。設定分四段：申請 LINE Developers 帳號、取得 Channel Secret 和 Access Token、寫入 OpenClaw 設定、設定 Webhook URL。

> ⚠️ **重要提醒**
> LINE Bot 不支援 `openclaw configure` 的互動式精靈，需要用指令直接寫入設定。
> 本 Skill 的步驟已經過實測，請照順序執行。

---

## Subagent 設定

### Task-Dispatch Subagents

| Subagent | 角色 | 觸發時機 |
|----------|------|---------|
| 步驟導航師（SA01） | 根據學員目前進度給出下一步具體指令 | 學員說「我在哪裡」、「下一步」 |
| 錯誤排查師（SA02） | 分析錯誤訊息給出具體解法 | 收到任何錯誤訊息時 |
| 截圖分析師（SA02） | 分析學員截圖確認設定是否正確 | 學員上傳截圖時 |

### Role-Persona Subagents

**主角色：親切的技術助教**
- 語氣：不假設對方懂技術，每步驟說清楚「做完你會看到什麼」
- 原則：LINE Developer Console 介面容易搞混，多用截圖確認

---

## 設定流程

### 第一步：建立 LINE Messaging API Channel

1. 前往 [LINE Developers Console](https://developers.line.biz/)
2. 登入 LINE 帳號
3. 建立 Provider（第一次使用需要）
4. 點擊 **Create a new channel**
5. 選擇 **Messaging API**
6. 填寫以下資訊：
   - Channel name：龍蝦助理（或你喜歡的名稱）
   - Channel description：AI 助理
   - Category / Subcategory：任意選擇
7. 勾選同意條款 → 點擊 **Create**

---

### 第二步：取得 Channel Secret 和 Access Token

**取得 Channel Secret：**
1. 進入剛建立的 Channel
2. 點擊 **Basic settings** 分頁
3. 找到 **Channel secret** → 點擊 **Copy**

**取得 Channel Access Token：**
1. 點擊 **Messaging API** 分頁
2. 滾到最下方找到 **Channel access token (long-lived)**
3. 點擊 **Issue** 產生 Token
4. 複製 Token（很長一串）

---

### 第三步：寫入 OpenClaw 設定

SSH 連線進 VM，執行以下三行指令：

```bash
sudo node /opt/openclaw/openclaw.mjs config set channels.line.enabled true
sudo node /opt/openclaw/openclaw.mjs config set channels.line.channelSecret "你的Channel_Secret"
sudo node /opt/openclaw/openclaw.mjs config set channels.line.accessToken "你的Access_Token"
```

寫入後重啟服務：

```bash
sudo systemctl restart openclaw
sleep 5
sudo systemctl status openclaw
```

確認 `Active: active (running)`。

---

### 第四步：設定 Webhook URL

1. 回到 LINE Developers Console → **Messaging API** 分頁
2. 找到 **Webhook URL** 欄位
3. 點擊 **Edit**，輸入：

```
http://你的VM公網IP/webhook
```

> 你的 VM 公網 IP 可以在 Oracle Cloud 控制台查到，
> 或在 VM 執行 `curl -s http://ifconfig.me`

4. 點擊 **Update** 儲存
5. 點擊 **Verify** 測試連線
6. 看到 **Success** 就完成了
7. 確認 **Use webhook** 開關是 **開啟** 狀態

---

### 第五步：關閉自動回覆

LINE 預設有自動回覆功能，會跟龍蝦衝突：

1. 點擊 **Messaging API** 分頁
2. 找到 **LINE Official Account features**
3. 點擊 **Auto-reply messages** 旁的 **Edit**
4. 進入 LINE Official Account Manager
5. 關閉 **自動回應訊息** 和 **加入好友的歡迎訊息**（可選）

---

### 第六步：加好友測試

1. 在 LINE Developers Console → **Messaging API** 分頁
2. 找到 **Bot basic ID** 或掃描 QR Code
3. 加龍蝦為好友
4. 發送一則訊息，龍蝦應該正常回應

---

## 常見錯誤排查

**Webhook Verify 失敗**

檢查以下幾點：
```bash
# 確認 nginx 正在跑
sudo systemctl status nginx

# 確認 openclaw 正在跑
sudo systemctl status openclaw

# 測試本地 webhook 是否有回應
curl -X POST http://localhost/webhook \
  -H 'Content-Type: application/json' \
  -d '{}'
```

若 nginx 沒跑：
```bash
sudo systemctl start nginx
```

**Oracle 防火牆需要開放 Port 80**

Oracle Cloud 的 VM 預設安全清單可能沒有開放 Port 80：

1. 登入 Oracle Cloud 控制台
2. 漢堡選單 → Networking → Virtual Cloud Networks
3. 點擊你的 VCN → Security Lists → Default Security List
4. Add Ingress Rules：
   - Source CIDR：`0.0.0.0/0`
   - Destination Port Range：`80`
5. 點 Add Ingress Rules 儲存

**龍蝦沒有回應**
```bash
sudo journalctl -u openclaw -n 20 --no-pager
```
找 `[line]` 開頭的錯誤訊息。

**Channel Secret 或 Token 錯誤**

重新執行設定指令，確認沒有多餘的空格：
```bash
sudo node /opt/openclaw/openclaw.mjs config set channels.line.channelSecret "正確的Secret"
sudo node /opt/openclaw/openclaw.mjs config set channels.line.accessToken "正確的Token"
sudo systemctl restart openclaw
```

---

## 注意事項

- LINE Bot 只能接收加好友後的訊息，無法主動發起對話（LINE 平台限制）
- 個人 LINE 帳號不支援自動化，一定要用 **Messaging API Bot**
- Access Token 有效期很長（long-lived），但如果 Channel 被刪除就失效
- 免費方案每月有 500 則免費訊息，超過需付費
