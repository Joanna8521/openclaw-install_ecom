---
name: e92-amazon-inventory
description: 同步 Amazon 賣家中心（Seller Central）的商品庫存到龍蝦系統，涵蓋 FBA 倉庫庫存與自發貨庫存，低於門檻時主動通知並建議補貨，與 E03 庫存預警整合。支援 SP-API 自動同步與截圖手動輸入兩種模式。
user-invocable: true
metadata: {"openclaw":{"emoji":"🌍","always":false}}
---

# Amazon 庫存同步

將 Amazon Seller Central 的商品庫存（FBA + 自發貨）同步進龍蝦系統，與 E03 庫存預警整合，低庫存時主動通知。

支援兩種模式：
- **基本模式**：Seller Central 截圖手動輸入，馬上能用
- **進階模式**：串接 Amazon SP-API，完全自動同步

---

## 輸入方式

### 截圖輸入（基本模式，推薦）
傳入 Amazon Seller Central 庫存頁截圖，Vision 直接分析，不需等待提示。

### 手動輸入（基本模式）
```
Amazon FBA 耳機黑色剩 85、白色剩 12
自發貨 耳機黑色剩 20
```
直接記錄，不需等待提示。

### Amazon SP-API 自動同步（進階模式）
```
/e92 設定API
```

---

## API 設定流程（Amazon SP-API）

```
/e92 設定API
```

Amazon SP-API 設定比其他平台複雜，分三階段：

### 階段一：在 Seller Central 申請開發者帳號
```
Amazon SP-API 設定步驟：

階段一：申請開發者資格
1. 登入 Amazon Seller Central
   sellercentral.amazon.com（或 .co.jp 日本站等）

2. 右上角 → 設定 → 使用者權限
   → 找到「第三方開發人員和應用程式」
   → 點選「造訪 Manage Your Apps」

3. 點選「新增應用程式」→「造訪開發者中心」
   → 填寫開發者資料和使用目的

⚠️ Amazon 開發者申請需要 1-2 週審核
   審核期間請用截圖模式

審核通過後繼續階段二 →
```

### 階段二：取得 API 憑證
```
階段二：取得 API 憑證

1. 在開發者中心建立新應用程式
2. 選擇「自用（Private）」類型
3. 取得以下三組資訊：
   • LWA Client ID
   • LWA Client Secret
   • Refresh Token（完成 OAuth 授權後取得）

4. 在 IAM（AWS Identity and Access Management）建立角色
   → 取得 AWS Access Key ID 和 Secret Access Key

請輸入 LWA Client ID：
```

### 階段三：選擇站點和庫存類型
```
階段三：設定同步範圍

請選擇 Amazon 站點：
1) amazon.co.jp（日本）← 台灣賣家最常用
2) amazon.com（美國）
3) amazon.co.uk（英國）
4) 其他（手動輸入 Marketplace ID）

請選擇庫存類型（可多選）：
A) FBA 倉庫庫存（Amazon 幫你出貨）
B) 自發貨庫存（自己出貨）
C) 全部（A + B）
```

設定完成後：
```
✅ Amazon SP-API 連接成功！（日本站 / FBA + 自發貨）
已切換為自動同步模式，每天 07:00 自動抓取庫存。

目前商品庫存：
FBA 倉庫
• [商品A]  黑色：120 個 🟢
• [商品A]  白色：18 個  🟡

自發貨
• [商品A]  黑色：35 個  🟢
• [商品B]          12 個  🟡
```

---

## FBA 庫存的特殊邏輯

FBA 庫存有多種狀態，龍蝦分別處理：

| 狀態 | 說明 | 是否計入可用庫存 |
|------|------|----------------|
| Fulfillable | 可出貨的正常庫存 | ✅ 計入 |
| Inbound | 在途（送往 FBA 倉庫中）| ❌ 不計入，但顯示參考 |
| Reserved | 已下單待出貨 | ❌ 不計入 |
| Unfulfillable | 損壞或不可售 | ❌ 不計入 |

預警門檻使用 **Fulfillable 數量**，在途庫存另外標示供參考。

---

## 庫存同步與預警

同步後自動整合進 E03 庫存預警表：

```
📦 Amazon 庫存更新  2026/03/04 07:00（日本站）

FBA 倉庫（Fulfillable）
[商品A]（白色）  🟡 18 個  ← 注意
[商品A]（黑色）  🟢 120 個
[商品B]          🟡 12 個  ← 注意

FBA 在途（Inbound，供參考）
[商品A]（白色）  80 個（預計 3/10 入庫）

自發貨
[商品A]（黑色）  🟢 35 個

📊 完整庫存：[Google Sheets 連結]
```

FBA 庫存緊急時推送通知到 LINE（主要）或 Telegram / Discord：
```
🟡 Amazon FBA 庫存預警（日本站）

[商品A]（白色）FBA 可用 18 個 → 預估 12 天後需補貨
⚠️ FBA 補貨前置時間約 2-3 週，建議提早寄送

在途庫存：80 個（預計 3/10 入庫）
入庫後庫存充足，可先觀察

💡 若在途庫存順利入庫，暫無緊急補貨需求
📊 查看庫存：[Google Sheets 連結]
```

---

## Amazon 特有：FBA 補貨前置時間提醒

Amazon FBA 補貨需要：
1. 台灣出貨到 FBA 倉庫：7-14 天（空運）或 30-45 天（海運）
2. FBA 收貨入庫：3-7 天
3. 總前置時間：最短 10 天，最長 52 天

龍蝦在計算補貨建議時自動納入 FBA 前置時間：
```
💡 FBA 補貨建議
建議庫存：60 天銷量（一般平台 30 天 × 2，因為前置時間較長）
建議補貨量：日均銷量 3 件 × 60 天 - 目前可用庫存 18 個 = 162 個
```

---

## 依賴關係

- **C07** Sheets 資料庫 — 儲存庫存記錄
- **C10** 定時排程 — 每天自動同步
- **E03** 庫存預警 — 接收同步結果並判斷預警
- **E16** 跨境稅務試算 — Amazon 跨境成本計算

---

## 語氣要求
- 繁體中文
- Amazon SP-API 設定最複雜，分三階段說明，每完成一個階段給正向回饋
- FBA 庫存一定要區分 Fulfillable / Inbound / Reserved，不要混為一談
- FBA 補貨前置時間比台灣平台長很多，主動提醒學員提早規劃
- 在途庫存一定顯示，讓學員不要重複補貨

---

## Subagent 調教

**派遣類型**：sa02-analyst（數據龍蝦）
**角色人格**：精確的 FBA 庫存分析員，嚴格區分 Fulfillable、Inbound、Reserved 三種狀態，補貨建議納入 FBA 前置時間

**派遣時機**：收到 Amazon 庫存資料後，交給數據龍蝦依狀態分類並計算含前置時間的補貨建議，再更新到 E03 庫存表。SP-API 設定、OAuth 授權、IAM 角色建立由主 Skill 直接執行，不需派遣。

執行本 Skill 需要派遣 subagent 時，使用以下格式：

```
[PERSONA] 你是一位精確的 FBA 庫存分析員。只用 Fulfillable 數量作為可用庫存。Inbound 在途庫存單獨列出供參考，不加入可用庫存計算。補貨建議天數預設 60 天（FBA 前置時間比台灣平台長）。Fulfillable + Inbound 合計夠用時標記「在途庫存入庫後可緩解，建議觀察」。
[TASK] {從用戶輸入萃取的具體任務}
[CONSTRAINTS] {根據用戶情境填入限制條件，例如字數、通知門檻、目標平台}
```

Subagent 完成任務後，主龍蝦整合結果並以本 Skill 定義的格式回覆用戶。
