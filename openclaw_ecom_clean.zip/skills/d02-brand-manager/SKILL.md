---
name: d02-brand-manager
description: 多品牌檔案管理中心。管理 MEMORY.md 的「我的店」區塊，支援多品牌建檔、切換、驗證與摘要。學員說「新增品牌、切換品牌、品牌列表、編輯品牌、刪除品牌、我要設定品牌」「/brand」「/品牌」時呼叫此技能。
user-invocable: true
metadata: {"openclaw":{"emoji":"🏷️"}}
---

# D02 多品牌檔案管理中心

## 技能說明

讓同一位學員在單一龍蝦實例中管理多個電商品牌。每個品牌擁有獨立的 Profile JSON，儲存平台資訊、API 憑證、品牌語氣、主要品類等上下文。

**切換品牌的核心機制：** 切換時直接改寫 `MEMORY.md` 的「我的店」區塊，讓所有 E 系列技能無需任何修改即可自動讀取到正確的品牌上下文。

**指令總覽：**
```
/brand list              列出所有已建立的品牌
/brand new               建立新品牌（啟動引導式問卷）
/brand use [品牌名稱]    切換當前使用的品牌
/brand edit [品牌名稱]   編輯現有品牌資料
/brand delete [品牌名稱] 刪除品牌（需二次確認）
/brand status            查看當前啟用品牌摘要
```

---

## Profile JSON 標準結構

每個品牌儲存為 `~/.openclaw/workspace/profiles/[品牌ID].json`：

```json
{
  "brand_id": "brand_001",
  "brand_name": "[品牌顯示名稱]",
  "created_at": "2025-01-01T00:00:00+08:00",
  "last_updated": "2025-01-01T00:00:00+08:00",

  "identity": {
    "brand_alias": "[品牌簡稱]",
    "industry": "[產業別，如：美妝 / 家居 / 3C / 服飾]",
    "main_categories": ["[主力品類1]", "[主力品類2]"],
    "price_tier": "[平價 / 中價 / 高價 / 精品]",
    "target_audience": "[目標客群描述]",
    "brand_tone": "[品牌語氣，如：活潑親切 / 專業權威 / 文青質感]",
    "usp": "[品牌最大差異化賣點]",
    "taboo_words": ["[禁用詞1]", "[禁用詞2]"]
  },

  "platforms": {
    "shopee": {
      "enabled": false,
      "shop_id": "",
      "shop_name": "",
      "api_key": "",
      "api_secret": "",
      "main_store_url": ""
    },
    "momo": {
      "enabled": false,
      "seller_id": "",
      "api_key": "",
      "api_secret": ""
    },
    "app_91": {
      "enabled": false,
      "store_id": "",
      "api_token": ""
    },
    "pchome": {
      "enabled": false,
      "merchant_id": "",
      "api_key": ""
    },
    "yahoo": {
      "enabled": false,
      "store_id": "",
      "api_key": ""
    },
    "line_shopping": {
      "enabled": false,
      "channel_id": "",
      "channel_secret": ""
    }
  },

  "social": {
    "facebook_page_id": "",
    "facebook_access_token": "",
    "instagram_account_id": "",
    "line_oa_id": "",
    "line_oa_token": ""
  },

  "operations": {
    "shipping_default": "[預設出貨方式]",
    "return_policy_summary": "[退換貨政策摘要]",
    "customer_service_hours": "[客服時段]",
    "peak_seasons": ["[旺季1]", "[旺季2]"],
    "competitor_brands": ["[主要競品1]", "[主要競品2]"]
  },

  "notes": "[其他補充說明]"
}
```

---

## 子代理人架構

### 🦞 多品牌策略龍蝦（Role Persona）

你是「多品牌策略龍蝦」，熟悉台灣各大電商平台的品牌管理專家。說話直接、有條理，像一位有豐富實戰經驗的電商老手。核心任務是幫助學員建立清晰的品牌檔案，讓旗下每個龍蝦技能都能精準運作。

當學員同時有多品牌時，主動提醒「現在操作的是哪個品牌」，避免混用出錯。

---

### SA-D02-A：品牌建檔師

**觸發條件：** `/brand new` 或說「我要建立新品牌」

**任務：** 引導式問卷收集品牌資訊，填寫 Profile JSON，存檔後呼叫 SA-D02-B 切換至新品牌。

**執行流程：**

```
Step 1 — 基本識別
問：「這個品牌叫什麼名稱？（之後用這個名稱切換）」

Step 2 — 主要銷售平台（多選）
選項：蝦皮 / Momo / 91APP / PChome / Yahoo / LINE購物 / 其他

Step 3 — 各平台 API 資訊
針對 Step 2 選的平台逐一問 Shop ID 和 API Key。
還沒有 API 權限可輸入「待設定」跳過。

Step 4 — 品牌定位
主力品類 / 語氣風格 / 目標客群 / 核心賣點 / 禁用詞 / 主要競品

Step 5 — 確認並存檔
展示 Profile 摘要，學員確認後：
  1. 產生 brand_id（brand_001、brand_002 依序遞增）
  2. 寫入 ~/.openclaw/workspace/profiles/[brand_id].json
  3. 呼叫 SA-D02-B 的 switch_brand() 改寫 MEMORY.md
  4. 呼叫 SA-D02-C 驗證完整度
  5. 回報：「✅ 品牌「[品牌名]」建檔完成，已設為當前使用品牌。」
```

**防呆：**
- 品牌名稱不可重複，重複時詢問是否覆蓋或改名
- API 欄位填「待設定」時標記 `"pending": true`，不影響建檔
- 任何時候輸入 `/skip` 跳過當前欄位

---

### SA-D02-B：品牌切換官

**觸發條件：** `/brand use`、`/brand list`、`/brand delete`，或由 SA-D02-A 建檔完成後呼叫

**核心任務：** 切換品牌時，將目標品牌資料寫入 `MEMORY.md` 的「我的店」區塊。E 系列技能完全不需修改，切換後自動讀到新品牌上下文。

**Python 執行邏輯：**

```python
import json, os, re, glob
from datetime import datetime, timezone, timedelta

WORKSPACE   = os.path.expanduser("~/.openclaw/workspace")
MEMORY_PATH = os.path.join(WORKSPACE, "MEMORY.md")
PROFILE_DIR = os.path.join(WORKSPACE, "profiles")
ACTIVE_PATH = os.path.join(PROFILE_DIR, "active_brand.json")

PLATFORM_NAMES = {
    "shopee":       "蝦皮",
    "momo":         "Momo",
    "app_91":       "91APP",
    "pchome":       "PChome",
    "yahoo":        "Yahoo購物",
    "line_shopping":"LINE購物"
}

def tw_now() -> str:
    return datetime.now(timezone(timedelta(hours=8))).isoformat()

def get_enabled_platforms(platforms: dict) -> list:
    result = []
    for key, data in platforms.items():
        if data.get("enabled"):
            name = PLATFORM_NAMES.get(key, key)
            if not data.get("api_key") or data["api_key"] in ("", "待設定"):
                name += "（API待設定）"
            result.append(name)
    return result

def load_all_profiles() -> list:
    files = sorted(glob.glob(os.path.join(PROFILE_DIR, "brand_*.json")))
    profiles = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            profiles.append(json.load(fh))
    return profiles

# ── 核心：改寫 MEMORY.md 的「我的店」區塊 ──────────────────────
def switch_brand(brand_id: str) -> str:
    profile_path = os.path.join(PROFILE_DIR, f"{brand_id}.json")
    if not os.path.exists(profile_path):
        raise FileNotFoundError(f"找不到品牌檔案：{profile_path}")

    with open(profile_path, encoding="utf-8") as f:
        b = json.load(f)

    platforms_str  = "、".join(get_enabled_platforms(b["platforms"])) or "（尚未設定）"
    categories_str = "、".join(b["identity"].get("main_categories", []))
    competitors_str = "、".join(b["operations"].get("competitor_brands", [])) or "（未設定）"
    taboo_str      = "、".join(b["identity"].get("taboo_words", [])) or "（未設定）"
    peak_str       = "、".join(b["operations"].get("peak_seasons", [])) or "（未設定）"

    # 組新的「我的店」區塊
    # 注意：區塊開頭與結尾各留一個空行，讓 regex 能穩定抓邊界
    new_block = (
        "## 我的店\n\n"
        f"- 店名：{b['brand_name']}\n"
        f"- 品牌代稱：{b['identity'].get('brand_alias', b['brand_name'])}\n"
        f"- 主要銷售平台：{platforms_str}\n"
        f"- 主要商品類別：{categories_str}\n"
        f"- 價位帶：{b['identity'].get('price_tier', '')}\n"
        f"- 目標客群：{b['identity'].get('target_audience', '')}\n"
        f"- 品牌語氣：{b['identity'].get('brand_tone', '')}\n"
        f"- 核心賣點（USP）：{b['identity'].get('usp', '')}\n"
        f"- 禁用詞：{taboo_str}\n"
        f"- 主要競品：{competitors_str}\n"
        f"- 旺季：{peak_str}\n"
        f"- 客服時段：{b['operations'].get('customer_service_hours', '')}\n"
        f"- 退換貨政策：{b['operations'].get('return_policy_summary', '')}\n"
        f"- 品牌備註：{b.get('notes', '')}\n"
    )

    with open(MEMORY_PATH, encoding="utf-8") as f:
        memory = f.read()

    # 替換「## 我的店」到下一個「## 」之間的內容
    # 若找不到就附加到檔尾
    pattern = r'## 我的店\n.*?(?=\n## |\Z)'
    if re.search(pattern, memory, flags=re.DOTALL):
        new_memory = re.sub(pattern, new_block.rstrip(), memory, flags=re.DOTALL)
    else:
        new_memory = memory.rstrip() + "\n\n" + new_block

    with open(MEMORY_PATH, "w", encoding="utf-8") as f:
        f.write(new_memory)

    # 更新 active_brand.json
    os.makedirs(PROFILE_DIR, exist_ok=True)
    with open(ACTIVE_PATH, "w", encoding="utf-8") as f:
        json.dump({
            "current_brand_id":   brand_id,
            "current_brand_name": b["brand_name"],
            "switched_at":        tw_now()
        }, f, ensure_ascii=False, indent=2)

    return b["brand_name"]

# ── 指令：列出品牌 ─────────────────────────────────────────────
def cmd_list() -> str:
    profiles = load_all_profiles()
    if not profiles:
        return "你還沒有建立任何品牌！輸入 /brand new 開始吧。"

    current_id = ""
    if os.path.exists(ACTIVE_PATH):
        with open(ACTIVE_PATH, encoding="utf-8") as f:
            current_id = json.load(f).get("current_brand_id", "")

    lines = [f"📦 你目前共有 {len(profiles)} 個品牌：\n"]
    for b in profiles:
        platforms = get_enabled_platforms(b["platforms"])
        p_str  = "、".join(platforms) if platforms else "未設定平台"
        marker = "✅ " if b["brand_id"] == current_id else "   "
        tag    = "（當前使用）" if b["brand_id"] == current_id else ""
        lines.append(f"{marker}{b['brand_name']}{tag} — {p_str}")

    lines.append("\n輸入 /brand use [品牌名稱] 來切換")
    return "\n".join(lines)

# ── 指令：切換品牌 ─────────────────────────────────────────────
def cmd_use(brand_name: str) -> str:
    for b in load_all_profiles():
        if b["brand_name"] == brand_name or b["identity"].get("brand_alias") == brand_name:
            switched = switch_brand(b["brand_id"])
            return f"🔄 已切換至品牌「{switched}」，MEMORY 已更新，後續技能自動以此品牌執行。"
    return f"找不到品牌「{brand_name}」，請輸入 /brand list 確認名稱。"

# ── 指令：刪除品牌 ─────────────────────────────────────────────
def cmd_delete(brand_name: str, confirmed: bool = False) -> str:
    if not confirmed:
        return (f"⚠️ 確定要刪除品牌「{brand_name}」？\n"
                "這個操作無法復原，輸入「確認刪除」繼續，或任意文字取消。")

    profiles = load_all_profiles()
    current_id = ""
    if os.path.exists(ACTIVE_PATH):
        with open(ACTIVE_PATH, encoding="utf-8") as f:
            current_id = json.load(f).get("current_brand_id", "")

    for b in profiles:
        if b["brand_name"] == brand_name:
            fpath = os.path.join(PROFILE_DIR, f"{b['brand_id']}.json")
            # 若刪除的是當前品牌，自動切換到下一個
            if b["brand_id"] == current_id:
                remaining = [x for x in profiles if x["brand_id"] != b["brand_id"]]
                if remaining:
                    switch_brand(remaining[0]["brand_id"])
                elif os.path.exists(ACTIVE_PATH):
                    os.remove(ACTIVE_PATH)
            os.remove(fpath)
            return f"🗑️ 品牌「{brand_name}」已刪除。"

    return f"找不到品牌「{brand_name}」。"
```

---

### SA-D02-C：資料完整性驗證員

**觸發條件：** 建檔完成後自動觸發、或 `/brand edit` 儲存時觸發

**任務：** 檢查 Profile 欄位完整度，回報缺漏與 API 連通性。全部透過 Python 執行，LLM 不直接判斷。

```python
def validate_profile(profile: dict) -> dict:
    issues   = []
    warnings = []

    must_have = {
        "brand_name":               "品牌名稱",
        "identity.industry":        "產業別",
        "identity.main_categories": "主力品類",
        "identity.brand_tone":      "品牌語氣",
        "identity.target_audience": "目標客群",
        "identity.usp":             "核心賣點",
    }

    filled = 0
    for dotkey, label in must_have.items():
        val = profile
        for part in dotkey.split("."):
            val = val.get(part) if isinstance(val, dict) else None
        if val:
            filled += 1
        else:
            issues.append(f"必填欄位缺漏：{label}")

    for platform, data in profile["platforms"].items():
        if data.get("enabled"):
            if not data.get("api_key") or data["api_key"] in ("", "待設定"):
                name = PLATFORM_NAMES.get(platform, platform)
                warnings.append(f"{name} 已啟用但 API Key 尚未設定")

    score = int(filled / len(must_have) * 100)
    return {"score": score, "issues": issues, "warnings": warnings}
```

**輸出格式：**
```
📊 品牌「[品牌名]」資料完整度：83%

❌ 必須修正（影響技能運作）：
  · 核心賣點（USP）未填寫

⚠️ 建議補充：
  · 蝦皮 API Key 尚未設定，E03、E07 等技能無法執行
  · 禁用詞未設定，文案生成可能出現不適合詞彙

✅ 已就緒：品牌名稱、產業別、主力品類、品牌語氣、目標客群
```

---

### SA-D02-D：品牌摘要播報員

**觸發條件：** 切換品牌後自動觸發、或 `/brand status`

**任務：** 讀取 `active_brand.json` 與對應 Profile，輸出當前品牌一覽。

**輸出範例：**
```
🦞 當前品牌：[品牌名稱]
━━━━━━━━━━━━━━━━━━━━━━━━
🏷️  定位：[品類]｜[價位帶]｜[語氣]
👥  目標客群：[客群描述]
🌟  核心賣點：[USP]

📦 已連接平台：
  ✅ 蝦皮（shop_id: xxxxx）
  ✅ Momo
  ⚠️  91APP（API待設定）

📱 社群帳號：
  ✅ Facebook / Instagram
  ❌ LINE OA（未設定）

💡 目前共 [N] 個品牌，輸入 /brand list 切換
```

---

## 常見情境對話

**情境 A：第一次使用**
```
學員：/brand list
龍蝦：你還沒有建立任何品牌！輸入 /brand new 開始建立第一個品牌吧。
```

**情境 B：建立第二個品牌**
```
學員：/brand new
龍蝦：好的，來建立新品牌！
     你目前已有品牌「OO旗艦店」（蝦皮）。
     新品牌叫什麼名稱？
```

**情境 C：切換品牌**
```
學員：/brand use B品牌
龍蝦：🔄 已切換至品牌「B品牌」，MEMORY 已更新，後續技能自動以此品牌執行。
     （接著播報 B 品牌摘要）
```

**情境 D：忘記切換就執行技能（多品牌時才出現）**
```
學員：幫我寫蝦皮的促銷文案
龍蝦：⚠️ 當前品牌是「OO旗艦店」，確認要為這個品牌寫文案嗎？
     要換品牌請輸入 /brand use [品牌名稱]。
```

---

## 注意事項

- API Key、Secret 等敏感資訊**只在 Python 執行層使用**，絕不出現在 LLM 回應文字中
- 刪除品牌前必須二次確認，無強制刪除捷徑
- `brand_id` 建立後不可修改，只能改 `brand_name` 顯示名稱
- 切換後 MEMORY.md 的「我的店」即時生效，E 系列技能下一次呼叫就讀到新品牌資料
- MEMORY.md 的「我的店」區塊格式必須與範本一致，regex 才能穩定替換
- 所有日期時間統一 ISO 8601，時區台灣（UTC+8）
