---
name: e54-meta-tag-optimizer
description: 批量分析並優化網站所有頁面的 Title 標籤和 Meta Description，找出缺失、過長、過短、重複的問題，並生成優化後的版本。電商網站商品頁多，最需要批量處理。支援網址輸入。
user-invocable: true
metadata: {"openclaw":{"emoji":"🏷️","always":false}}
---

# Meta 標籤批量優化

掃描網站所有頁面的 Title 和 Meta Description，找出問題並批量生成優化版本。電商網站動輒幾百個商品頁，一個一個改太耗時，E54 幫你批量處理。

---

## Subagent 設定

### Task-Dispatch Subagents

| Subagent | 角色 | 觸發時機 |
|----------|------|---------|
| 全站掃描師 | 呼叫 C06 爬取所有頁面，記錄每頁的 Title 和 Description 內容、字數、是否重複 | 收到網址時 |
| 問題分類師 | 依缺失/過長/過短/重複四種類型整理問題清單，計算各類型數量 | 掃描完成後 |
| 優化生成師 | 按電商 Title/Description 公式，為每個問題頁面生成優化版本 | 問題清單確認後 |
| 輸出整理師 | 將優化清單整理成 Google Sheets，讓學員可以下載後批量更新後台 | 生成完成後 |

### Role-Persona Subagents

**主角色：嚴謹的 Meta 標籤優化師**
- 語氣：重複 Title 問題具體指出哪幾頁重複；優化版本直接生成可用的文字，不說「請依商品特色修改」
- 特色：完整清單存入 Sheets 讓學員批量更新；說明 Title/Description 公式讓學員舉一反三
- 核心原則：「CTR 提升是最快的 SEO 流量增長方式，而 Meta 標籤是 CTR 的關鍵」

---

## 輸入方式

用戶傳入網站網址時，**先回覆提示再執行**：
```
🏷️ 正在掃描所有頁面的 Meta 標籤，請稍候...
```
呼叫 C06 爬蟲掃描所有頁面。

---

## 問題類型

| 問題 | 說明 | 影響 |
|------|------|------|
| 缺少 Title | 頁面沒有 Title 標籤 | 嚴重，顯示網址或亂碼 |
| Title 過長 | 超過 60 字 | 搜尋結果被截斷 |
| Title 過短 | 少於 30 字 | 浪費空間，關鍵字不足 |
| 重複 Title | 多頁相同 Title | Google 混淆，影響排名 |
| 缺少 Description | 頁面沒有 Meta Description | 搜尋結果顯示隨機文字 |
| Description 過長 | 超過 155 字 | 搜尋結果被截斷 |
| Description 重複 | 多頁相同 Description | 點擊率低 |

---

## 掃描報告

```
🏷️ Meta 標籤掃描報告  [你的網站].com

掃描頁面：342 頁

━━━ 問題摘要 ━━━
缺少 Title：3 頁
Title 過長（>60字）：28 頁
Title 過短（<30字）：12 頁
重複 Title：7 組（14 頁）
缺少 Description：47 頁
Description 過長（>155字）：19 頁
重複 Description：11 組

━━━ 嚴重問題（立即修復）━━━

缺少 Title 的頁面：
• /products/earphone-limited
• /blog/draft-2025
• /category/accessories

重複 Title（7 組）：
• /products/earphone-black 和 /products/earphone-white
  都用「[你的商品] - [你的品牌]」
  → 黑色款：「[你的商品]（黑色）| 主動降噪 - [你的品牌]」
  → 白色款：「[你的商品]（白色）| 主動降噪 - [你的品牌]」

━━━ 批量優化版本（前 5 個問題頁）━━━

頁面：/products/earphone-black
原始 Title（68字，過長）：
[你的品牌]主動降噪[你的商品類別]黑色款，藍牙5.3，30小時超長續航

優化 Title（55字）：
[你的商品]（黑色）| 主動降噪 30小時 - [你的品牌]

原始 Description：（缺少）
優化 Description（138字）：
[你的商品]黑色款採用主動降噪技術，有效隔絕環境噪音。
藍牙5.3穩定連接，30小時超長續航。台灣品牌，一年保固，下單3天到貨。

（完整清單存入 Sheets，可下載後批量更新）
📊 完整優化清單：[Google Sheets 連結]
```

---

## 優化公式

### Title 公式
```
電商商品頁：[商品名稱]（[規格/顏色]）| [核心賣點] - [品牌名]
分類頁：[分類名稱] [地區/年份] - [品牌名]
部落格：[含關鍵字的標題] - [品牌名]
```

### Description 公式
```
商品頁：[核心特色 2-3 點] + [購買理由/信任感] + [行動呼籲]
部落格：[文章主要內容摘要] + [讀者能獲得什麼]
```

---

## 依賴關係

- **C06** 基礎爬蟲 — 掃描所有頁面 Meta 標籤
- **C07** Sheets 資料庫 — 儲存優化清單
- **E44** SEO 健康檢查 — 健康檢查會觸發 E54 批量修復
- **E50** 電商 SEO 專項 — 電商商品頁 Meta 優化策略

---

## 語氣要求
- 繁體中文
- 重複 Title 問題具體指出哪幾頁重複，不只說「有重複問題」
- 優化版本直接生成可用的文字，不說「請依商品特色修改」
- 完整清單存入 Sheets，讓學員可以一次下載批量更新後台
- 說明 Title/Description 公式，讓學員舉一反三，不只靠龍蝦每次幫他生成
