# 🦞 AICLAW × OpenClaw — 電商+行銷+SEO 班技能包

> 課程專用，請勿外傳。共 **109 個技能**，覆蓋電商營運、行銷自動化、SEO、數據分析、內容發布全流程。

---

## 🚀 快速安裝（約 15 分鐘）

### STEP 1：建立 VM（三選一，推薦 Oracle）

| 平台 | 費用 | 規格 | 在哪執行 |
|---|---|---|---|
| **Oracle Cloud**（推薦） | NT$0/月 永久免費 | 4 OCPU / 24 GB ARM | Oracle Cloud Shell |
| AWS EC2（備案） | 約 NT$900–1,100/月 | t3.medium | AWS CloudShell |
| GCP Compute（備案） | 約 NT$700–900/月 | e2-medium | GCP Cloud Shell |

**Oracle**（在 Oracle Cloud Shell 執行）：
```bash
curl -fsSL https://raw.githubusercontent.com/Joanna8521/openclaw-install_ecom/main/setup_vm.sh \
  -o setup_vm.sh && chmod +x setup_vm.sh && bash setup_vm.sh
```

**AWS**：改 URL 成 `setup_vm_aws.sh`，在 AWS CloudShell 跑。

**GCP**：改 URL 成 `setup_vm_gcp.sh`，在 GCP Cloud Shell 跑。

完成後會輸出 SSH 指令和 VM 的 Public IP。

---

### STEP 2：SSH 進入 VM

```bash
ssh -i ~/.ssh/openclaw_ecom_key ubuntu@你的VM的IP
```

---

### STEP 3：在 VM 內裝龍蝦主程式 + 全部 109 個技能

> ⚠️ **必須用下面這個指令（不可用 `curl | sudo bash`，會吞掉互動輸入）**

```bash
curl -fsSL https://raw.githubusercontent.com/Joanna8521/openclaw-install_ecom/main/bootstrap.sh \
  -o bootstrap.sh && chmod +x bootstrap.sh && sudo ./bootstrap.sh
```

安裝過程會依序問：

1. **AI 引擎選擇**：Claude（推薦，繁中支援最好）或 Gemini
2. **AI API Key**：Anthropic Console 或 Google AI Studio 取得
3. **LINE Bot 設定**（主要頻道）：Channel Secret + Channel Access Token
4. **Telegram Bot Token**（可選）：從 `@BotFather` 取得
5. **課程存取碼 PAT**：老師在課程群組提供，`github_pat_` 開頭

全部輸入完成後，腳本會自動：
- 裝 Node.js v22、OpenClaw 主程式（pnpm build）
- git clone 109 個 Skills 到 `/root/.openclaw/skills`
- 建立 MEMORY.md 長期記憶檔
- 設定 Nginx 反向代理
- 啟動 systemd 服務
- 引導 Telegram Bot 配對 / LINE Webhook 設定

---

## 📚 第一次使用（安裝完成後）

### 1. 到 Bot 傳 `/d01` 做入學診斷

D01 會帶你填品牌基本資料（店名、主要平台、客群、競品…），填完會直接寫入 `MEMORY.md`，之後每次對話龍蝦都記得。

### 2. 想新增更多品牌？傳 `/brand new`

D02 管理多品牌檔案。你可以有多個品牌同時存在、用 `/brand use 品牌名` 切換。

### 3. 增量更新記憶

- 「記得我的品牌語氣要親切」→ 龍蝦寫入工作規則
- 「忘記今天設的廣告時間」→ 龍蝦確認後刪除
- 「你記得什麼」→ 龍蝦摘要目前記憶

---

## 🧠 記憶系統

龍蝦的「腦」是一份 markdown 檔案：`/root/.openclaw/workspace/MEMORY.md`

每次對話開始前，這份檔案會自動被注入到 context，讓龍蝦記得你的店家資訊、溝通偏好、常用資源和工作規則。

**記憶分工**：

| 記憶技能 | 管的範圍 | 觸發方式 |
|---|---|---|
| **D02** 品牌管理 | 「我的店」區塊 | `/brand new`、`/brand use`、`/brand list`、`/brand edit` |
| **C00** 記憶管理 | 其他區塊（溝通偏好、工作規則、資源） | 「記得…」「忘記…」「更新我的…」「你記得什麼」 |

**想手動編輯？**
```bash
sudo nano /root/.openclaw/workspace/MEMORY.md
sudo systemctl restart openclaw   # 讓龍蝦重新讀記憶
```

---

## 🛠️ 故障排除

**龍蝦沒反應？跑自助健檢**

```bash
curl -fsSL https://raw.githubusercontent.com/Joanna8521/openclaw-install_ecom/main/diagnose.sh \
  -o diagnose.sh && chmod +x diagnose.sh && sudo ./diagnose.sh
```

`diagnose.sh` 會檢查系統環境、OpenClaw 服務、Nginx、Skills 目錄、設定檔、API 連線等 8 個區塊，結尾會印出一段可以直接複製貼給老師的摘要。

---

## 📋 Skill 清單（109 個）

### 系統層 C00–C10（11 個）

| Skill | 說明 |
|---|---|
| 🧠 C00 | 記憶管理（更新 MEMORY.md） |
| ☁️ C01 | Oracle Cloud 部署管理 |
| 🔗 C02 | Google 服務整合（Sheets / Drive / Calendar） |
| ✈️ C03 | Telegram Bot 設定與管理 |
| 💚 C04 | LINE Bot 設定與管理 |
| 🌐 C05 | 沙盒瀏覽器 |
| 🕷️ C06 | 基礎爬蟲 |
| 📊 C07 | Google Sheets 資料庫 |
| 📁 C08 | Google Drive 管理 |
| 📋 C09 | 每日報告 |
| ⏰ C10 | 定時排程 |

### 入學與品牌 D01–D02（2 個）

| Skill | 說明 |
|---|---|
| 🦞 D01 | 電商班入學診斷（首次必跑） |
| 🏷️ D02 | 多品牌檔案管理中心 |

### 電商營運 E01–E18（18 個）

| Skill | 說明 |
|---|---|
| 🔍 E01 | 競品價格監控 |
| ⭐ E02 | 評價監控 |
| 📦 E03 | 庫存預警 |
| 🚨 E04 | 訂單異常偵測 |
| ✏️ E05 | 商品標題優化 |
| 💬 E06 | 負評回覆生成 |
| 📝 E07 | 商品描述生成 |
| 🎯 E08 | 促銷活動規劃 |
| 🏆 E09 | 暢銷榜追蹤 |
| 📢 E10 | 廣告成效監控 |
| ⚖️ E11 | 跨平台比價 |
| ✅ E12 | 商品上架品質檢查 |
| 📦 E13 | 退貨原因分析 |
| 🤖 E14 | 客服 FAQ Bot |
| 🚚 E15 | 物流異常提醒 |
| 🌏 E16 | 跨境稅務試算 |
| 💰 E17 | 利潤計算器 |
| 🏭 E18 | 採購管理 |

### 行銷自動化 E19–E38（20 個）

| Skill | 說明 |
|---|---|
| 📣 E19 | 廣告文案生成 |
| 📅 E20 | 行銷行事曆 |
| 📧 E21 | EDM 電子報生成 |
| 👂 E22 | 社群監控 |
| 🌟 E23 | KOL 名單管理 |
| 🔬 E24 | A/B 測試分析 |
| 🎯 E25 | 再行銷受眾規劃 |
| 🔗 E26 | UTM 追蹤碼管理 |
| 💚 E27 | LINE 官方帳號管理 |
| 🎨 E28 | 廣告素材建議 |
| 🤝 E29 | 聯盟行銷管理 |
| 🎉 E30 | 節日行銷快報 |
| 👥 E31 | 推薦人追蹤 |
| 🛒 E32 | 棄單挽回 |
| 🎬 E33 | 短影音腳本生成 |
| 👤 E34 | 顧客分眾（RFM） |
| 📡 E35 | 直播腳本與管理 |
| ⭐ E36 | 評價邀請自動化 |
| 📸 E37 | UGC / 開箱文管理 |
| 📱 E38 | 社群貼文排程 |

### SEO 專業 E39–E58（20 個）

| Skill | 說明 |
|---|---|
| 🔍 E39 | 關鍵字研究 |
| 📈 E40 | 關鍵字排名追蹤 |
| 🧠 E41 | 搜尋意圖分析 |
| 🔎 E42 | SERP 搜尋結果頁分析 |
| 🕳️ E43 | 內容缺口分析 |
| 🏥 E44 | SEO 健康檢查 |
| 🕷️ E45 | 技術 SEO 爬蟲 |
| 🕸️ E46 | 內部連結優化 |
| ⚡ E47 | Core Web Vitals 監控 |
| 🔗 E48 | 反向連結監控 |
| 🏷️ E49 | Schema 結構化資料生成 |
| 🛍️ E50 | 電商 SEO 專項 |
| 📍 E51 | Google 商家檔案管理 |
| ✍️ E52 | AI SEO 文章生成 |
| 🕵️ E53 | 競品流量分析 |
| 🏷️ E54 | Meta 標籤批量優化 |
| 🚀 E55 | 頁面速度監控 |
| 🖥️ E56 | Google Search Console 整合 |
| 📊 E57 | GA4 × SEO 整合分析 |
| 📋 E58 | SEO 週報 |

### 數據分析 E59–E78（20 個）

| Skill | 說明 |
|---|---|
| 📊 E59 | GA4 全站分析摘要 |
| 📣 E60 | 廣告成效分析 |
| 💎 E61 | LTV 顧客終身價值計算 |
| 🎯 E62 | CAC 獲客成本追蹤 |
| 🔽 E63 | 轉換漏斗分析 |
| 📅 E64 | 月度行銷報告 |
| 🗂️ E65 | 多平台數據整合 |
| ⚖️ E66 | 付費 vs 自然流量比較 |
| 🛒 E67 | AOV 客單價追蹤 |
| 🔄 E68 | 回購率分析 |
| 📆 E69 | 每日營收報告 |
| 👑 E70 | 會員忠誠度管理 |
| 🔍 E71 | 競品廣告監控 |
| 🏆 E72 | 商品績效分析 |
| 📦 E73 | 庫存周轉率分析 |
| ↩️ E74 | 退貨率分析 |
| ⏰ E75 | 熱銷時段分析 |
| 🎯 E76 | 促銷活動效果回顧 |
| 🚨 E77 | 數據異常偵測 |
| 📋 E78 | 數據分析週報 |

### 內容與發布 E79–E88（10 個）

| Skill | 說明 |
|---|---|
| 🚀 E79 | 多平台商品同步發布 |
| 📱 E80 | 社群內容跨平台發布 |
| 🎪 E81 | 促銷活動跨平台同步 |
| 📨 E82 | 電子報 + LINE 同步發送 |
| 🗃️ E83 | 圖文素材分發管理 |
| 📆 E84 | 跨渠道內容日曆 |
| 📋 E85 | 商品上架模板庫 |
| 🔄 E86 | 內容格式轉換 |
| ⚡ E87 | 緊急更新與下架 |
| ✅ E88 | 發布狀態追蹤 |

### 電商平台庫存整合 E89–E92（4 個）

| Skill | 說明 |
|---|---|
| 🛒 E89 | PChome 24h 庫存同步 |
| 🟣 E90 | Yahoo 購物中心庫存同步 |
| 🔴 E91 | Momo mo+店庫存同步 |
| 🌍 E92 | Amazon 賣家中心庫存同步 |

### 子代理 SA01–SA04（4 個，內部使用）

> 學員不會直接呼叫，由其他 skill 派遣任務給它們處理。

| Subagent | 負責 |
|---|---|
| ✍️ SA01 | 文案龍蝦（撰寫 / 改寫 / 翻譯） |
| 📊 SA02 | 數據龍蝦（Python 計算 / 數字分析） |
| 🕷️ SA03 | 爬蟲龍蝦（網頁資訊擷取） |
| ⚖️ SA04 | 判斷龍蝦（策略評估 / 決策建議） |

---

## 🔧 常用指令

```bash
# 查看龍蝦狀態
sudo systemctl status openclaw

# 重新啟動龍蝦
sudo systemctl restart openclaw

# 查看即時 log
sudo journalctl -u openclaw -f

# 更新 Skills（如果老師推了新版）
cd /root/.openclaw/skills && sudo git pull

# 安裝或更新單一 skill（例如補裝 D01）
curl -fsSL https://raw.githubusercontent.com/Joanna8521/openclaw-install_ecom/main/install_skill.sh \
  -o install_skill.sh && sudo ./install_skill.sh d01-ecom-init

# 補裝 Discord 頻道
curl -fsSL https://raw.githubusercontent.com/Joanna8521/openclaw-install_ecom/main/setup_discord.sh \
  -o setup_discord.sh && chmod +x setup_discord.sh && sudo ./setup_discord.sh
```

---

## 📂 重要檔案位置

| 路徑 | 用途 |
|---|---|
| `/opt/openclaw/` | OpenClaw 主程式（git clone 來的） |
| `/root/.openclaw/skills/` | 109 個 SKILL.md |
| `/root/.openclaw/workspace/MEMORY.md` | 長期記憶檔（最重要！） |
| `/root/.openclaw/workspace/persona.json` | 結構化品牌資料（D02 維護） |
| `/root/.openclaw/.env` | AI API Key 等環境變數 |
| `/root/.openclaw/skills_pat` | GitHub PAT |
| `/root/.openclaw/config.json` | OpenClaw 設定（channels / model 等） |

---

## 🆘 問題回報

1. 先跑 `diagnose.sh` 自助健檢
2. 把結尾的 4 行摘要 + 有 ⚠️ 或 ❌ 的項目複製
3. 在課程群組貼給老師，或 Telegram 私訊

龍蝦遇到你解決不了的問題時，它會主動告訴你要不要重啟服務或找老師 🦞
